# Heart Attack Risk Prediction using Machine Learning

This project builds a machine learning model to predict the risk of heart attacks in diabetic patients.
It demonstrates the end-to-end AI workflow from data preprocessing to deployment using Streamlit.

## Features
- Exploratory Data Analysis (EDA)
- Data preprocessing and feature engineering
- Model training and comparison (Random Forest, XGBoost, Logistic Regression)
- Performance evaluation (Accuracy, ROC-AUC, Confusion Matrix)
- Streamlit-based web application
- Future directions: Model interpretability using SHAP

## Run the app
Install dependencies:

```bash
pip install -r requirements.txt
```

Then run:

```bash
streamlit run app.py
```
