import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Heart Attack Predictor", layout="centered")
st.title("💓 Heart Attack Risk Predictor for Diabetic Patients")

uploaded_file = st.file_uploader("Upload CSV with medical data", type=["csv"])
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.subheader("Dataset Overview")
    st.dataframe(df.head())

    if 'target' not in df.columns:
        st.error("The dataset must contain a 'target' column (0: No risk, 1: At risk).")
    else:
        st.subheader("Correlation Heatmap")
        corr = df.corr()
        fig, ax = plt.subplots()
        sns.heatmap(corr, annot=True, cmap='coolwarm', ax=ax)
        st.pyplot(fig)

        X = df.drop("target", axis=1)
        y = df["target"]

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        model_option = st.selectbox("Choose Model", ["Random Forest", "Logistic Regression", "XGBoost"])
        if model_option == "Random Forest":
            model = RandomForestClassifier()
        elif model_option == "Logistic Regression":
            model = LogisticRegression()
        else:
            model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        st.subheader("Classification Report")
        st.text(classification_report(y_test, y_pred))

        st.subheader("Confusion Matrix")
        cm = confusion_matrix(y_test, y_pred)
        fig2, ax2 = plt.subplots()
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax2)
        st.pyplot(fig2)
